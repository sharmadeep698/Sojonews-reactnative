import React from 'react';
import {StyleSheet, Text, View, TouchableOpacity} from 'react-native';
import FontAwesome from 'react-native-vector-icons/FontAwesome';
import MaterialIcons from 'react-native-vector-icons/MaterialIcons';

const MainScreen = ({navigation}) => {
  return (
    <View style={styles.bottomContainer}>
      <TouchableOpacity
        style={styles.button}
        onPress={() => {
          navigation.push('WelcomeLogin');
        }}>
        {/* <FontAwesome name="google" size={24} color="#545760" /> */}
        <Text style={styles.buttonText}>Continue by logging in</Text>
      </TouchableOpacity>
      <TouchableOpacity
        style={styles.button}
        onPress={() => {
          navigation.push('WelcomeSignup');
        }}>
        {/* <MaterialIcons name="email" size={24} color="#545760" /> */}
        <Text style={styles.buttonText}>Create an account</Text>
      </TouchableOpacity>
    </View>
  );
};

export default MainScreen;

const styles = StyleSheet.create({
  bottomContainer: {
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    flex: 1,
  },
  button: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    padding: 13,
    backgroundColor: '#E7E7E8',
    borderRadius: 8,
    // elevation: 1,
    // borderWidth: 1,
    // borderColor: '',

    marginBottom: 20,
  },

  buttonText: {
    // marginLeft: 10,
    fontSize: 16,
    color: '#545760',
  },
});
