import {StyleSheet, Text, View} from 'react-native';
import React from 'react';

const TopicsScreen = () => {
  return (
    <View>
      <Text>TopicsScreen</Text>
    </View>
  );
};

export default TopicsScreen;

const styles = StyleSheet.create({});
