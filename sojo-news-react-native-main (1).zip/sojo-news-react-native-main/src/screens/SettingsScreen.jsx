import {StyleSheet, Text, View, Button, StatusBar} from 'react-native';
import React, {useEffect} from 'react';
import {logoutUser} from './../helper/auth';
import {useNavigation} from '@react-navigation/native';

const SettingsScreen = () => {
  const navigation = useNavigation();

  useEffect(() => {
    const timeout = setTimeout(() => {
      StatusBar.setBackgroundColor('#27B161');
    }, 1); // set a small delay here (in milliseconds)

    return () => clearTimeout(timeout);
  }, [navigation]);

  return (
    <View>
      <Button
        title="Logout"
        onPress={() => {
          logoutUser();
          navigation.reset({index: 0, routes: [{name: 'Auth'}]});
        }}
      />
    </View>
  );
};

export default SettingsScreen;

const styles = StyleSheet.create({});
